**Issue:** add link to pelletier/go-toml issue here

Explanation of what this pull request does.

More detailed description of the decisions being made and the reasons why (if the patch is non-trivial).
